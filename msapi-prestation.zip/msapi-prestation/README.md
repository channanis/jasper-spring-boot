# msapi-prestation — Migration Java 6/EAP legacy → Java 21 / Spring Boot 3

Microservice autonome portant la gestion des demandes de prestation
(avance, rachat partiel, rachat total), extrait du monolithe JAX-RS legacy.
Toute la logique métier (RG) a été **conservée à l'identique** : mêmes seuils,
même ordre de contrôle, mêmes cas d'erreur.

## Ce qui a changé, et pourquoi

| Legacy | Nouveau | Raison |
|---|---|---|
| `RestPrestation` (JAX-RS, `@Path`) | `PrestationController` (Spring MVC, `@RestController`) | Cohérence avec la stack Spring Boot 3 cible |
| Login lu depuis `HttpServletRequest.getSession()` | Header `X-User-Login` propagé par le BFF/gateway | Un microservice est stateless ; la session HTTP ne survit pas à un déploiement scalé horizontalement |
| `ServiceException` + toujours HTTP 200 avec un `code` dans le JSON | Exceptions typées (`PrestationBusinessException`, codes `PrestationErrorCode`) + `@RestControllerAdvice` renvoyant du `ProblemDetail` (RFC 7807) avec le bon statut HTTP | Une erreur métier n'est pas un succès HTTP ; simplifie aussi le client (plus besoin de parser un champ `code` dans un body 200) |
| `Customer`/`Contract` lus en base via DAO locaux | `CustomerClient` / `ContractClient` (Feign) vers des microservices dédiés | Le monolithe est découpé par domaine ; ce service ne possède que les données Prestation |
| `dateSous`, `mtencour`, `mtavce` fournis par le **client mobile** dans le JSON | Lus depuis `ContractDTO` (source serveur, via Feign) | Ce sont des données utilisées pour calculer des plafonds financiers — les laisser saisissables par le client était une faille (un utilisateur pouvait mentir sur son encours pour contourner les 80%/50%) |
| `fileExt` fourni par le client dans le JSON | Dérivé côté serveur du nom du fichier multipart reçu | Évite une incohérence entre l'extension déclarée et le fichier réellement envoyé |
| ~10 champs `@Value` FTP éclatés | `FtpProperties` / `PrestationProperties` (`@ConfigurationProperties`, records) | Config typée, groupée, testable, plus de chaînes de propriétés dispersées dans les classes de service |
| `FileValidationUtil.validateUploadedFile` (statique) | `FileValidationService` (bean injectable) | Testable, remplaçable, ne dépend plus d'un état statique |
| Logique métier mélangée avec logs `+ "..."` en concaténation, `throws IOException, ServiceException` sur toute la chaîne | `PrestationBusinessRules` pure (aucune dépendance web/JPA), levée d'exceptions non checked | Les RG sont testables unitairement sans mocker Servlet/DAO (voir `PrestationBusinessRulesTest`) |
| Table `prestation` unique connaissant tout | Entités JPA `Prestation` / `HistoryPrestation`, enums typés (`TypeProcedure`, `ModeReglement`, `StatutPrestation`) au lieu de `String`/`Constants.XXX` | Sécurité de typage à la compilation, élimine une classe de bugs (faute de frappe sur une constante `String`) |

## Endpoints

- `POST /api/v1/prestations` (multipart : partie JSON `prestation` + fichier optionnel `releveIdentiteBancaire`)
  — remplace `POST /private/prestation/demandePrestation`.
- `PUT /api/v1/prestations/{prestationUid}/statut` — remplace le `majPrestation` interne
  (le endpoint REST correspondant n'était pas présent dans le code fourni ; la logique
  métier `checkFieldMajPrestation`/`updatePrestation` a été portée dans
  `PrestationServiceImpl#updateStatus`, à brancher sur le contrat d'API réel une fois connu).

## Ce qui reste à faire avant mise en production

1. Confirmer le contrat des microservices `customer-service` et `contract-service`
   (`CustomerClient`, `ContractClient`) — ils sont ici définis avec le contrat minimal
   nécessaire au domaine Prestation.
2. Brancher l'authentification réelle du header `X-User-Login` (ex. validation côté
   gateway/Keycloak, cf. le travail en cours sur le BFF).
3. `ddl-auto: validate` suppose un schéma déjà géré par Flyway/Liquibase — à ajouter si
   ce n'est pas déjà le cas ailleurs dans l'écosystème.
4. Sécuriser `PUT .../statut` (le token seul, dans un header, est un contrôle faible
   pour un endpoint interne — envisager mTLS ou un scope OAuth2 dédié entre services).
