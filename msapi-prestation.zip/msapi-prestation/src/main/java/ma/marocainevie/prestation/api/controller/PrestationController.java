package ma.marocainevie.prestation.api.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import ma.marocainevie.prestation.api.dto.request.PrestationCreateRequest;
import ma.marocainevie.prestation.api.dto.request.PrestationStatusUpdateRequest;
import ma.marocainevie.prestation.api.dto.response.PrestationResponse;
import ma.marocainevie.prestation.api.mapper.PrestationMapper;
import ma.marocainevie.prestation.domain.model.Prestation;
import ma.marocainevie.prestation.domain.service.PrestationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.UncheckedIOException;

/**
 * Remplace l'ancien endpoint JAX-RS {@code POST /private/prestation/demandePrestation}.
 * L'utilisateur n'est plus lu depuis la session HTTP (incompatible avec des microservices
 * stateless) mais propagé par le BFF/gateway via l'en-tête {@code X-User-Login}, cohérent
 * avec le pattern BFF déjà en place sur les autres services.
 */
@RestController
@RequiredArgsConstructor
public class PrestationController {

    private static final String LOGIN_HEADER = "X-User-Login";

    private final PrestationService prestationService;
    private final PrestationMapper prestationMapper;

    @PostMapping(
            path = "/api/v1/prestations",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<PrestationResponse> create(
            @RequestHeader(LOGIN_HEADER) String login,
            @RequestPart("prestation") @Valid PrestationCreateRequest request,
            @RequestPart(value = "releveIdentiteBancaire", required = false) MultipartFile releveIdentiteBancaire) {

        Prestation created = prestationService.createPrestation(
                login,
                request,
                readBytes(releveIdentiteBancaire),
                originalFileName(releveIdentiteBancaire));

        return ResponseEntity.status(HttpStatus.CREATED).body(prestationMapper.toResponse(created));
    }

    @PutMapping(
            path = "/api/v1/prestations/{prestationUid}/statut",
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public ResponseEntity<PrestationResponse> updateStatus(
            @PathVariable String prestationUid,
            @RequestHeader("X-Prestation-Token") String token,
            @RequestBody @Valid PrestationStatusUpdateRequest request) {

        Prestation updated = prestationService.updateStatus(prestationUid, token, request);
        return ResponseEntity.ok(prestationMapper.toResponse(updated));
    }

    private byte[] readBytes(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            return null;
        }
        try {
            return file.getBytes();
        } catch (IOException e) {
            throw new UncheckedIOException("Impossible de lire le fichier joint", e);
        }
    }

    private String originalFileName(MultipartFile file) {
        return file == null ? null : file.getOriginalFilename();
    }
}
