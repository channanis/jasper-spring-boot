package ma.marocainevie.prestation.api.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import ma.marocainevie.prestation.domain.model.enums.ModeReglement;
import ma.marocainevie.prestation.domain.model.enums.TypeProcedure;

/**
 * Corps JSON de la demande de prestation (partie "prestation" du multipart form d'origine).
 * Note : {@code dateSouscription}, le montant en cours et l'avance en cours ne sont plus
 * saisis par le client — ils sont désormais lus depuis le microservice Contract, qui fait
 * autorité, au lieu d'être fournis (et donc potentiellement falsifiables) par l'appelant.
 */
public record PrestationCreateRequest(

        @NotNull Integer numCat,
        @NotBlank String police,
        @NotNull TypeProcedure typeProcedure,

        boolean versementEntreprise,
        String nomEntreprise,

        boolean valeurMaximale,
        @Positive float montantOperation,

        @NotNull ModeReglement modeReglement,
        String numeroCompteBancaire,

        @NotBlank String nomPrenom,
        @Email String email
) {
}
