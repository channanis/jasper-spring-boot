package ma.marocainevie.prestation.api.dto.request;

import jakarta.validation.constraints.NotNull;
import ma.marocainevie.prestation.domain.model.enums.StatutPrestation;

/** Corps JSON pour la mise à jour de statut d'une prestation (ancien "majPrestation"). */
public record PrestationStatusUpdateRequest(
        @NotNull StatutPrestation statut,
        String quittance,
        String message
) {
}
