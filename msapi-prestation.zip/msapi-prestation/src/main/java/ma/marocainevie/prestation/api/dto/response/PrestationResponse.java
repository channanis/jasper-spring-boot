package ma.marocainevie.prestation.api.dto.response;

import ma.marocainevie.prestation.domain.model.enums.ModeReglement;
import ma.marocainevie.prestation.domain.model.enums.StatutPrestation;
import ma.marocainevie.prestation.domain.model.enums.TypeProcedure;

import java.time.LocalDateTime;

public record PrestationResponse(
        String prestationUid,
        TypeProcedure typeProcedure,
        StatutPrestation statut,
        float montantOperation,
        ModeReglement modeReglement,
        String police,
        LocalDateTime dateCreation
) {
}
