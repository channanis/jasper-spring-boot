package ma.marocainevie.prestation.api.mapper;

import ma.marocainevie.prestation.api.dto.response.PrestationResponse;
import ma.marocainevie.prestation.domain.model.Prestation;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface PrestationMapper {

    PrestationResponse toResponse(Prestation prestation);
}
