package ma.marocainevie.prestation.config;

import ma.marocainevie.prestation.domain.exception.PrestationAccessDeniedException;
import ma.marocainevie.prestation.domain.exception.PrestationBusinessException;
import ma.marocainevie.prestation.infrastructure.storage.FileStorageException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * Traduit les exceptions du domaine en réponses HTTP standardisées (RFC 7807).
 * Remplace l'ancien comportement qui renvoyait systématiquement HTTP 200 avec un
 * code d'erreur dans le corps JSON — pratique non conforme REST et gardée hors de
 * ce microservice volontairement.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(PrestationBusinessException.class)
    public ResponseEntity<ProblemDetail> handleBusinessException(PrestationBusinessException e) {
        log.warn("Erreur métier : {}", e.errorCode());
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(e.errorCode().httpStatus(), e.getMessage());
        problem.setTitle(e.errorCode().name());
        return ResponseEntity.status(e.errorCode().httpStatus()).body(problem);
    }

    @ExceptionHandler(PrestationAccessDeniedException.class)
    public ResponseEntity<ProblemDetail> handleAccessDenied(PrestationAccessDeniedException e) {
        log.warn("Accès refusé : {}", e.getMessage());
        return ResponseEntity.status(HttpStatus.FORBIDDEN)
                .body(ProblemDetail.forStatusAndDetail(HttpStatus.FORBIDDEN, e.getMessage()));
    }

    @ExceptionHandler(FileStorageException.class)
    public ResponseEntity<ProblemDetail> handleFileStorage(FileStorageException e) {
        log.error("Erreur de stockage de fichier", e);
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                .body(ProblemDetail.forStatusAndDetail(HttpStatus.SERVICE_UNAVAILABLE,
                        "Le service de dépôt de fichier est momentanément indisponible"));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ProblemDetail> handleValidation(MethodArgumentNotValidException e) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, "Requête invalide");
        e.getBindingResult().getFieldErrors().forEach(fieldError ->
                problem.setProperty(fieldError.getField(), fieldError.getDefaultMessage()));
        return ResponseEntity.badRequest().body(problem);
    }
}
