package ma.marocainevie.prestation.domain.exception;

/**
 * Levée quand le token fourni pour la mise à jour d'une prestation ne correspond pas
 * au token attendu (remplace l'ancienne {@code AuthenticationExeption} / FORBIDDEN).
 */
public class PrestationAccessDeniedException extends RuntimeException {

    public PrestationAccessDeniedException() {
        super("Token invalide pour cette prestation");
    }
}
