package ma.marocainevie.prestation.domain.exception;

/**
 * Exception métier levée par les règles de gestion (RG) du domaine Prestation.
 * Remplace l'ancienne {@code ServiceException}.
 */
public class PrestationBusinessException extends RuntimeException {

    private final PrestationErrorCode errorCode;

    public PrestationBusinessException(PrestationErrorCode errorCode) {
        super(errorCode.defaultMessage());
        this.errorCode = errorCode;
    }

    public PrestationErrorCode errorCode() {
        return errorCode;
    }
}
