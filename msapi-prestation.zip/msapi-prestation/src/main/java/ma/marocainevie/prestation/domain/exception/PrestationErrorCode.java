package ma.marocainevie.prestation.domain.exception;

import org.springframework.http.HttpStatus;

/**
 * Codes d'erreur métier (RG) pour le domaine Prestation.
 * Remplace l'ancien {@code ServiceExceptionCode} en portant en plus le statut HTTP
 * et un message par défaut, pour éviter la duplication faite auparavant dans les logs.
 */
public enum PrestationErrorCode {

    CUSTOMER_EMPTY("Client introuvable", HttpStatus.NOT_FOUND),
    FIELD_LAST_NAME_EMPTY("Le nom/prénom est obligatoire", HttpStatus.BAD_REQUEST),
    FIELD_POLICE_EMPTY("Le numéro de police est obligatoire", HttpStatus.BAD_REQUEST),
    NUMCAT_EMPTY("La catégorie du contrat est obligatoire", HttpStatus.BAD_REQUEST),
    FIELD_ENTREPRISE_EMPTY("Le nom de l'entreprise est obligatoire pour un versement entreprise", HttpStatus.BAD_REQUEST),
    FIELD_EMAIL_FORMAT_ERROR("Le format de l'email est invalide", HttpStatus.BAD_REQUEST),
    FIELD_BIRTHDATE_EMPTY("La date de naissance du client est manquante", HttpStatus.UNPROCESSABLE_ENTITY),
    FIELD_DATE_SOUSCRIPTION_EMPTY("La date de souscription est obligatoire", HttpStatus.BAD_REQUEST),

    FIELD_N_COMPTE_EMPTY("Le numéro de compte bancaire est obligatoire pour un virement", HttpStatus.BAD_REQUEST),
    FIELD_N_COMPTE_ONLY_DIGITS("Le numéro de compte bancaire doit être numérique", HttpStatus.BAD_REQUEST),
    FIELD_N_COMPTE_EXACT_24("Le numéro de compte bancaire (RIB) doit contenir exactement 24 chiffres", HttpStatus.BAD_REQUEST),
    FIELD_FILE_EMPTY("Le relevé d'identité bancaire est obligatoire pour un virement", HttpStatus.BAD_REQUEST),
    FIELD_FILE_TOO_LARGE("Le fichier dépasse la taille maximale autorisée", HttpStatus.PAYLOAD_TOO_LARGE),
    FIELD_FILE_INVALID_EXTENSION("Extension de fichier non autorisée", HttpStatus.BAD_REQUEST),

    CONTRACT_EMPTY("Contrat introuvable", HttpStatus.NOT_FOUND),
    CONTRACT_NANTI("Le contrat est nanti, la demande ne peut pas être traitée", HttpStatus.CONFLICT),

    AGE_CRITERIA("Le client doit avoir au moins 50 ans pour une avance", HttpStatus.CONFLICT),
    DURE_CONTRAT_CRITERIA("Le contrat doit avoir au moins 8 ans d'ancienneté pour une avance", HttpStatus.CONFLICT),
    MONTANT_SUPERIEUR_80_ERROR("Le montant demandé dépasse 80% de l'encours", HttpStatus.CONFLICT),
    AVANCE_NON_REMBOURSE_ERROR("Une avance non remboursée existe déjà sur ce contrat", HttpStatus.CONFLICT),

    MONTANT_SUPERIEUR_50_ERROR("Le montant demandé dépasse 50% de l'encours", HttpStatus.CONFLICT),
    AVANCE_ENCOURS_ERROR("Une avance est en cours sur ce contrat", HttpStatus.CONFLICT),
    NOMBRE_RACHAT_ERROR("Le nombre maximum de rachats partiels est atteint", HttpStatus.CONFLICT),

    PRESTATION_EMPTY("Prestation introuvable", HttpStatus.NOT_FOUND),
    STATUS_EXIST("Le statut fourni est déjà celui de la prestation", HttpStatus.CONFLICT);

    private final String defaultMessage;
    private final HttpStatus httpStatus;

    PrestationErrorCode(String defaultMessage, HttpStatus httpStatus) {
        this.defaultMessage = defaultMessage;
        this.httpStatus = httpStatus;
    }

    public String defaultMessage() {
        return defaultMessage;
    }

    public HttpStatus httpStatus() {
        return httpStatus;
    }
}
