package ma.marocainevie.prestation.domain.model;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ma.marocainevie.prestation.domain.model.enums.StatutPrestation;

import java.time.LocalDateTime;

/** Trace d'audit associée à chaque création / changement de statut d'une prestation. */
@Entity
@Table(name = "history_prestation")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HistoryPrestation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "prestation_id")
    private Prestation prestation;

    private LocalDateTime dateModification;

    @Enumerated(EnumType.STRING)
    private StatutPrestation statut;

    private String modifiePar;
}
