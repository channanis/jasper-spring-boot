package ma.marocainevie.prestation.domain.model;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ma.marocainevie.prestation.domain.model.enums.ModeReglement;
import ma.marocainevie.prestation.domain.model.enums.StatutPrestation;
import ma.marocainevie.prestation.domain.model.enums.TypeProcedure;

import java.time.LocalDateTime;

/**
 * Entité "prestation" : demande d'avance / rachat partiel / rachat total sur un contrat.
 * Portage direct de l'ancienne entité Hibernate 3, sans changement de schéma de colonnes.
 */
@Entity
@Table(name = "prestation")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Prestation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String releveIdentiteBancaire;
    private boolean versementEntreprise;
    private String nomEntreprise;
    private boolean valeurMaximale;
    private float montantOperation;

    @Enumerated(EnumType.STRING)
    private ModeReglement modeReglement;

    private String numeroCompteBancaire;
    private LocalDateTime dateCreation;
    private LocalDateTime dateModification;
    private Integer numCat;
    private String police;

    @Enumerated(EnumType.STRING)
    private StatutPrestation codsit;

    @Enumerated(EnumType.STRING)
    private TypeProcedure typeProcedure;

    private String cin;
    private String login;
    private String prestationUid;
    private String quittance;
    private LocalDateTime dateTransfert;
    private String usr;
    private String typ;
    private String token;
    private String commentaire;
    private String libNumCat;
}
