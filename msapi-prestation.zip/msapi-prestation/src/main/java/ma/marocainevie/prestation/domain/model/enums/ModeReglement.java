package ma.marocainevie.prestation.domain.model.enums;

/** Mode de règlement demandé pour la prestation. */
public enum ModeReglement {
    VIREMENT,
    CHEQUE
}
