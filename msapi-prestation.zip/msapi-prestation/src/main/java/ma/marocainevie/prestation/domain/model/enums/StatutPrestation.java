package ma.marocainevie.prestation.domain.model.enums;

/** Statut (codsit) du cycle de vie d'une prestation. */
public enum StatutPrestation {
    DEMANDE_MOBILE,
    EN_COURS,
    VALIDEE,
    REJETEE,
    ANNULEE
}
