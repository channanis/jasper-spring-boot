package ma.marocainevie.prestation.domain.model.enums;

/**
 * Type de procédure d'une demande de prestation.
 * Le code court (avance -> A, rachat partiel -> RP, rachat total -> RT) est porté
 * par l'enum elle-même à la place de l'ancienne méthode {@code generateTyp(String)}.
 */
public enum TypeProcedure {

    AVANCE("A"),
    RACHAT_PARTIEL("RP"),
    RACHAT_TOTAL("RT");

    private final String code;

    TypeProcedure(String code) {
        this.code = code;
    }

    public String code() {
        return code;
    }
}
