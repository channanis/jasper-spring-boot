package ma.marocainevie.prestation.domain.service;

/**
 * Abstraction du stockage de fichiers (pièces jointes des demandes de prestation).
 * Permet de changer d'implémentation (FTP historique, SFTP, object storage...) sans
 * toucher à la logique métier qui, elle, ne connaît que ce contrat.
 */
public interface FileStorageService {

    /**
     * Dépose {@code content} sous {@code fileName} dans le dossier logique {@code folder}.
     *
     * @return le chemin/URL relatif du fichier stocké, à persister sur la prestation.
     */
    String store(byte[] content, String fileName, String folder);
}
