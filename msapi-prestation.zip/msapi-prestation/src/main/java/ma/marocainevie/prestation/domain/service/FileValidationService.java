package ma.marocainevie.prestation.domain.service;

import ma.marocainevie.prestation.domain.exception.PrestationBusinessException;
import ma.marocainevie.prestation.domain.exception.PrestationErrorCode;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * Validation du fichier joint à une demande de prestation (relevé d'identité bancaire).
 * Remplace l'ancien {@code FileValidationUtil}, en centralisant la liste d'extensions
 * autorisées au lieu de la dupliquer par appelant.
 */
@Component
public class FileValidationService {

    private static final Set<String> ALLOWED_EXTENSIONS = Set.of("pdf", "jpg", "jpeg", "png");
    private static final long BYTES_PER_MEGABYTE = 1_000_000L;

    public void validate(byte[] content, String fileExtension, int maxFileSizeMb) {
        if (fileExtension == null || !ALLOWED_EXTENSIONS.contains(fileExtension.toLowerCase())) {
            throw new PrestationBusinessException(PrestationErrorCode.FIELD_FILE_INVALID_EXTENSION);
        }
        if ((content.length / BYTES_PER_MEGABYTE) > maxFileSizeMb) {
            throw new PrestationBusinessException(PrestationErrorCode.FIELD_FILE_TOO_LARGE);
        }
    }
}
