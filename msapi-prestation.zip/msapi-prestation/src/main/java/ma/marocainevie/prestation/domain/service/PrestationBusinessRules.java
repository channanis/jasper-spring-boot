package ma.marocainevie.prestation.domain.service;

import ma.marocainevie.prestation.api.dto.request.PrestationCreateRequest;
import ma.marocainevie.prestation.domain.exception.PrestationBusinessException;
import ma.marocainevie.prestation.domain.exception.PrestationErrorCode;
import ma.marocainevie.prestation.domain.model.enums.ModeReglement;
import ma.marocainevie.prestation.domain.model.enums.TypeProcedure;
import ma.marocainevie.prestation.infrastructure.client.dto.ContractDTO;
import ma.marocainevie.prestation.infrastructure.client.dto.CustomerDTO;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.Period;
import java.util.regex.Pattern;

/**
 * Règles de gestion (RG) de la demande de prestation.
 * Portage 1:1 des méthodes {@code checkFieldDemandePrestation}, {@code checkContractNanti},
 * {@code checkRGAvance} et {@code checkRGRachatPartiel} de l'ancien {@code PrestationServiceImpl} :
 * seuils, ordre des contrôles et messages d'erreur sont inchangés.
 */
@Component
public class PrestationBusinessRules {

    private static final Logger log = LoggerFactory.getLogger(PrestationBusinessRules.class);

    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "[a-zA-Z0-9+._%\\-+]{1,256}@[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}(\\.[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25})+");
    private static final Pattern DIGITS_ONLY = Pattern.compile("[0-9]+");

    private static final int RIB_LENGTH = 24;
    private static final int AGE_MINIMUM_AVANCE = 50;
    private static final int ANCIENNETE_MINIMUM_AVANCE_ANNEES = 8;
    private static final int PLAFOND_AVANCE_PERCENT = 80;
    private static final int PLAFOND_RACHAT_PARTIEL_PERCENT = 50;
    private static final int NOMBRE_MAX_RACHATS_PARTIELS = 3;

    /** Contrôles de champs obligatoires / formats, avant toute règle métier plus lourde. */
    public void checkFieldDemandePrestation(CustomerDTO customer, PrestationCreateRequest request) {
        if (customer == null) {
            fail(PrestationErrorCode.CUSTOMER_EMPTY);
        }
        if (StringUtils.isBlank(request.nomPrenom())) {
            fail(PrestationErrorCode.FIELD_LAST_NAME_EMPTY);
        }
        if (StringUtils.isBlank(request.police())) {
            fail(PrestationErrorCode.FIELD_POLICE_EMPTY);
        }
        if (request.numCat() == null) {
            fail(PrestationErrorCode.NUMCAT_EMPTY);
        }
        if (request.versementEntreprise() && StringUtils.isBlank(request.nomEntreprise())) {
            fail(PrestationErrorCode.FIELD_ENTREPRISE_EMPTY);
        }
        if (StringUtils.isNotBlank(request.email()) && !EMAIL_PATTERN.matcher(request.email()).matches()) {
            fail(PrestationErrorCode.FIELD_EMAIL_FORMAT_ERROR);
        }
        if (customer.dateNaissance() == null) {
            fail(PrestationErrorCode.FIELD_BIRTHDATE_EMPTY);
        }
    }

    /** Le contrat ne doit pas être nanti pour pouvoir traiter la demande. */
    public void checkContractNanti(ContractDTO contract) {
        if (contract == null) {
            fail(PrestationErrorCode.CONTRACT_EMPTY);
        }
        if (contract.nanti()) {
            fail(PrestationErrorCode.CONTRACT_NANTI);
        }
    }

    /**
     * Contrôles spécifiques au virement : RIB obligatoire, numérique, 24 caractères,
     * et fichier joint obligatoire (validé séparément par {@link FileValidationService}).
     */
    public void checkVirement(PrestationCreateRequest request, boolean fileProvided) {
        if (request.modeReglement() != ModeReglement.VIREMENT) {
            return;
        }
        if (StringUtils.isBlank(request.numeroCompteBancaire())) {
            fail(PrestationErrorCode.FIELD_N_COMPTE_EMPTY);
        }
        if (!DIGITS_ONLY.matcher(request.numeroCompteBancaire()).matches()) {
            fail(PrestationErrorCode.FIELD_N_COMPTE_ONLY_DIGITS);
        }
        if (request.numeroCompteBancaire().length() != RIB_LENGTH) {
            fail(PrestationErrorCode.FIELD_N_COMPTE_EXACT_24);
        }
        if (!fileProvided) {
            fail(PrestationErrorCode.FIELD_FILE_EMPTY);
        }
    }

    /**
     * RG avance : âge >= 50, ancienneté du contrat >= 8 ans, montant <= 80% de l'encours
     * (ou plafonnement automatique si {@code valeurMaximale}), et pas d'avance non remboursée.
     *
     * @return le montant final de l'opération (peut différer de {@code request.montantOperation()}
     *         si {@code valeurMaximale} est demandé).
     */
    public float applyRGAvance(PrestationCreateRequest request, CustomerDTO customer, ContractDTO contract) {
        if (request.typeProcedure() != TypeProcedure.AVANCE) {
            return request.montantOperation();
        }
        int age = Period.between(customer.dateNaissance(), LocalDate.now()).getYears();
        int anciennete = Period.between(contract.dateSouscription(), LocalDate.now()).getYears();

        if (age < AGE_MINIMUM_AVANCE) {
            fail(PrestationErrorCode.AGE_CRITERIA);
        }
        if (anciennete < ANCIENNETE_MINIMUM_AVANCE_ANNEES) {
            fail(PrestationErrorCode.DURE_CONTRAT_CRITERIA);
        }

        float plafond = plafond(contract.montantEnCours(), PLAFOND_AVANCE_PERCENT);
        float montant = plafonnerOuVerifier(request, plafond, PrestationErrorCode.MONTANT_SUPERIEUR_80_ERROR);

        if (contract.montantAvanceEnCours() > 0) {
            fail(PrestationErrorCode.AVANCE_NON_REMBOURSE_ERROR);
        }
        return montant;
    }

    /**
     * RG rachat partiel : montant <= 50% de l'encours (ou plafonnement automatique),
     * pas d'avance en cours, et au plus 3 rachats partiels déjà effectués sur le contrat.
     *
     * @return le montant final de l'opération.
     */
    public float applyRGRachatPartiel(PrestationCreateRequest request, ContractDTO contract) {
        if (request.typeProcedure() != TypeProcedure.RACHAT_PARTIEL) {
            return request.montantOperation();
        }
        float plafond = plafond(contract.montantEnCours(), PLAFOND_RACHAT_PARTIEL_PERCENT);
        float montant = plafonnerOuVerifier(request, plafond, PrestationErrorCode.MONTANT_SUPERIEUR_50_ERROR);

        if (contract.montantAvanceEnCours() > 0) {
            fail(PrestationErrorCode.AVANCE_ENCOURS_ERROR);
        }
        if (contract.nombreRachatsPartiels() != null && contract.nombreRachatsPartiels() > NOMBRE_MAX_RACHATS_PARTIELS) {
            fail(PrestationErrorCode.NOMBRE_RACHAT_ERROR);
        }
        return montant;
    }

    private float plafonnerOuVerifier(PrestationCreateRequest request, float plafond, PrestationErrorCode depassementCode) {
        if (request.valeurMaximale()) {
            return plafond;
        }
        if (request.montantOperation() > plafond) {
            fail(depassementCode);
        }
        return request.montantOperation();
    }

    private float plafond(float montantEnCours, int percent) {
        return (montantEnCours * percent) / 100f;
    }

    private void fail(PrestationErrorCode errorCode) {
        log.warn("Règle de gestion violée : {}", errorCode);
        throw new PrestationBusinessException(errorCode);
    }
}
