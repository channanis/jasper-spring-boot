package ma.marocainevie.prestation.domain.service;

import ma.marocainevie.prestation.api.dto.request.PrestationCreateRequest;
import ma.marocainevie.prestation.api.dto.request.PrestationStatusUpdateRequest;
import ma.marocainevie.prestation.domain.model.Prestation;

/**
 * Cas d'usage du domaine Prestation. Remplace l'ancien {@code PrestationService} JAX-RS.
 */
public interface PrestationService {

    /**
     * Crée une nouvelle demande de prestation pour le client authentifié.
     *
     * @param login              login du client (propagé par le BFF/gateway, plus lu en session)
     * @param request            corps JSON de la demande
     * @param attachment         contenu du fichier joint (RIB), {@code null} si absent
     * @param attachmentFileName nom original du fichier joint, {@code null} si absent
     */
    Prestation createPrestation(String login,
                                 PrestationCreateRequest request,
                                 byte[] attachment,
                                 String attachmentFileName);

    /**
     * Met à jour le statut d'une prestation existante après vérification du token
     * (remplace l'ancien "majPrestation").
     */
    Prestation updateStatus(String prestationUid, String token, PrestationStatusUpdateRequest request);
}
