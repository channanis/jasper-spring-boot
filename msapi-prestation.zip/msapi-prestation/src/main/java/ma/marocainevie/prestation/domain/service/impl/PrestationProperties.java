package ma.marocainevie.prestation.domain.service.impl;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Regroupe {@code ma_marocainevie_selfcare_mobile_url_img_prestations} et {@code max_file_size}
 * de l'ancienne configuration, jusqu'ici lus séparément via {@code @Value}.
 * Bindée depuis le préfixe {@code selfcare.mobile.prestation} d'application.yml.
 */
@ConfigurationProperties(prefix = "selfcare.mobile.prestation")
public record PrestationProperties(
        String imageBaseUrl,
        int maxFileSizeMb
) {
}
