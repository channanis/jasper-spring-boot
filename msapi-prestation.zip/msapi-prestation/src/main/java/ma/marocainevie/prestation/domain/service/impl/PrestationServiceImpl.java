package ma.marocainevie.prestation.domain.service.impl;

import feign.FeignException;
import lombok.RequiredArgsConstructor;
import ma.marocainevie.prestation.api.dto.request.PrestationCreateRequest;
import ma.marocainevie.prestation.api.dto.request.PrestationStatusUpdateRequest;
import ma.marocainevie.prestation.domain.exception.PrestationAccessDeniedException;
import ma.marocainevie.prestation.domain.exception.PrestationBusinessException;
import ma.marocainevie.prestation.domain.exception.PrestationErrorCode;
import ma.marocainevie.prestation.domain.model.HistoryPrestation;
import ma.marocainevie.prestation.domain.model.Prestation;
import ma.marocainevie.prestation.domain.model.enums.StatutPrestation;
import ma.marocainevie.prestation.domain.service.FileStorageService;
import ma.marocainevie.prestation.domain.service.FileValidationService;
import ma.marocainevie.prestation.domain.service.PrestationBusinessRules;
import ma.marocainevie.prestation.domain.service.PrestationService;
import ma.marocainevie.prestation.infrastructure.client.ContractClient;
import ma.marocainevie.prestation.infrastructure.client.CustomerClient;
import ma.marocainevie.prestation.infrastructure.client.dto.ContractDTO;
import ma.marocainevie.prestation.infrastructure.client.dto.CustomerDTO;
import ma.marocainevie.prestation.infrastructure.repository.HistoryPrestationRepository;
import ma.marocainevie.prestation.infrastructure.repository.PrestationRepository;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class PrestationServiceImpl implements PrestationService {

    private static final Logger log = LoggerFactory.getLogger(PrestationServiceImpl.class);
    private static final String PRESTATION_FOLDER = "prestations";
    private static final String MODIFIE_PAR_MOBILE = "User Mobile";
    private static final String MODIFIE_PAR_LMV = "LMV";

    private final CustomerClient customerClient;
    private final ContractClient contractClient;
    private final PrestationBusinessRules businessRules;
    private final FileValidationService fileValidationService;
    private final FileStorageService fileStorageService;
    private final PrestationRepository prestationRepository;
    private final HistoryPrestationRepository historyPrestationRepository;
    private final PrestationProperties prestationProperties;

    @Override
    @Transactional
    public Prestation createPrestation(String login, PrestationCreateRequest request,
                                        byte[] attachment, String attachmentFileName) {
        log.debug("Début création prestation : login={}, typeProcedure={}", login, request.typeProcedure());

        CustomerDTO customer = fetchCustomer(login);
        businessRules.checkFieldDemandePrestation(customer, request);

        ContractDTO contract = fetchContract(customer.cin(), request.numCat(), request.police());
        businessRules.checkContractNanti(contract);

        float montantAvance = businessRules.applyRGAvance(request, customer, contract);
        float montantRachatPartiel = businessRules.applyRGRachatPartiel(request, contract);
        float montantOperation = resolveMontantOperation(request, montantAvance, montantRachatPartiel);

        businessRules.checkVirement(request, attachment != null);

        String storedFileName = null;
        if (attachment != null) {
            String fileExtension = extractExtension(attachmentFileName);
            fileValidationService.validate(attachment, fileExtension, prestationProperties.maxFileSizeMb());
            storedFileName = generateFileName(fileExtension);
            fileStorageService.store(attachment, storedFileName, PRESTATION_FOLDER);
        }

        Prestation saved = savePrestation(request, customer, contract, montantOperation, storedFileName);
        recordHistory(saved, StatutPrestation.DEMANDE_MOBILE, MODIFIE_PAR_MOBILE);

        log.debug("Fin création prestation : uid={}", saved.getPrestationUid());
        return saved;
    }

    @Override
    @Transactional
    public Prestation updateStatus(String prestationUid, String token, PrestationStatusUpdateRequest request) {
        log.debug("Début mise à jour statut prestation : uid={}", prestationUid);

        Prestation prestation = prestationRepository.findByPrestationUid(prestationUid)
                .orElseThrow(() -> new PrestationBusinessException(PrestationErrorCode.PRESTATION_EMPTY));

        if (!prestation.getToken().equals(token)) {
            throw new PrestationAccessDeniedException();
        }
        if (request.statut() == prestation.getCodsit()) {
            throw new PrestationBusinessException(PrestationErrorCode.STATUS_EXIST);
        }

        LocalDateTime now = LocalDateTime.now();
        prestation.setCodsit(request.statut());
        prestation.setDateModification(now);
        prestation.setQuittance(request.quittance());
        if (StringUtils.isNotBlank(request.message())) {
            prestation.setCommentaire(formatCommentaire(request.message(), now));
        }
        prestationRepository.save(prestation);

        recordHistory(prestation, request.statut(), MODIFIE_PAR_LMV);

        log.debug("Fin mise à jour statut prestation : uid={}", prestationUid);
        return prestation;
    }

    private CustomerDTO fetchCustomer(String login) {
        try {
            return customerClient.findByLogin(login);
        } catch (FeignException.NotFound e) {
            throw new PrestationBusinessException(PrestationErrorCode.CUSTOMER_EMPTY);
        }
    }

    private ContractDTO fetchContract(String cin, Integer numCat, String police) {
        try {
            return contractClient.getContract(cin, numCat, police);
        } catch (FeignException.NotFound e) {
            throw new PrestationBusinessException(PrestationErrorCode.CONTRACT_EMPTY);
        }
    }

    /** Les deux RG (avance / rachat partiel) sont mutuellement exclusives par type de procédure. */
    private float resolveMontantOperation(PrestationCreateRequest request, float montantAvance, float montantRachatPartiel) {
        return switch (request.typeProcedure()) {
            case AVANCE -> montantAvance;
            case RACHAT_PARTIEL -> montantRachatPartiel;
            case RACHAT_TOTAL -> request.montantOperation();
        };
    }

    private Prestation savePrestation(PrestationCreateRequest request, CustomerDTO customer,
                                       ContractDTO contract, float montantOperation, String storedFileName) {
        LocalDateTime now = LocalDateTime.now();
        Prestation prestation = Prestation.builder()
                .prestationUid(UUID.randomUUID().toString())
                .versementEntreprise(request.versementEntreprise())
                .nomEntreprise(request.nomEntreprise())
                .valeurMaximale(request.valeurMaximale())
                .montantOperation(montantOperation)
                .modeReglement(request.modeReglement())
                .dateCreation(now)
                .dateModification(now)
                .numCat(request.numCat())
                .police(request.police())
                .codsit(StatutPrestation.DEMANDE_MOBILE)
                .typeProcedure(request.typeProcedure())
                .cin(customer.cin())
                .login(customer.login())
                .usr(generateUsr(customer))
                .numeroCompteBancaire(request.numeroCompteBancaire())
                .typ(request.typeProcedure().code())
                .token(UUID.randomUUID().toString())
                .libNumCat(contract.libNumCat())
                .build();

        if (storedFileName != null) {
            prestation.setReleveIdentiteBancaire(prestationProperties.imageBaseUrl() + storedFileName);
        }
        return prestationRepository.save(prestation);
    }

    private void recordHistory(Prestation prestation, StatutPrestation statut, String modifiePar) {
        HistoryPrestation history = HistoryPrestation.builder()
                .prestation(prestation)
                .dateModification(LocalDateTime.now())
                .statut(statut)
                .modifiePar(modifiePar)
                .build();
        historyPrestationRepository.save(history);
    }

    private String generateUsr(CustomerDTO customer) {
        if (StringUtils.isBlank(customer.nom()) || StringUtils.isBlank(customer.prenom())) {
            return "";
        }
        return customer.prenom().charAt(0) + "." + customer.nom();
    }

    private String generateFileName(String fileExtension) {
        return "Prestation_" + System.currentTimeMillis() + "." + fileExtension;
    }

    private String extractExtension(String originalFileName) {
        if (originalFileName == null || !originalFileName.contains(".")) {
            return "";
        }
        return originalFileName.substring(originalFileName.lastIndexOf('.') + 1);
    }

    private String formatCommentaire(String message, LocalDateTime time) {
        return "[" + MODIFIE_PAR_LMV + " - " + time + "] " + message;
    }
}
