package ma.marocainevie.prestation.infrastructure.client;

import ma.marocainevie.prestation.infrastructure.client.dto.ContractDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "contract-service", url = "${contract-service.url}", path = "/internal/contracts")
public interface ContractClient {

    /**
     * @throws feign.FeignException.NotFound si aucun contrat ne correspond, à traduire
     *         côté service en {@link ma.marocainevie.prestation.domain.exception.PrestationErrorCode#CONTRACT_EMPTY}.
     */
    @GetMapping
    ContractDTO getContract(@RequestParam("cin") String cin,
                             @RequestParam("numCat") Integer numCat,
                             @RequestParam("police") String police);
}
