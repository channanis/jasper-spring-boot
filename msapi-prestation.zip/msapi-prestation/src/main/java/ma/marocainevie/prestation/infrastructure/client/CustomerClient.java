package ma.marocainevie.prestation.infrastructure.client;

import ma.marocainevie.prestation.infrastructure.client.dto.CustomerDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "customer-service", url = "${customer-service.url}", path = "/internal/customers")
public interface CustomerClient {

    /**
     * @throws feign.FeignException.NotFound si aucun client ne correspond au login,
     *         à traduire côté service en {@link ma.marocainevie.prestation.domain.exception.PrestationErrorCode#CUSTOMER_EMPTY}.
     */
    @GetMapping("/{login}")
    CustomerDTO findByLogin(@PathVariable("login") String login);
}
