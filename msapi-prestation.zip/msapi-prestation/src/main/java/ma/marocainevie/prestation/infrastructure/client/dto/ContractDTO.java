package ma.marocainevie.prestation.infrastructure.client.dto;

import java.time.LocalDate;

/**
 * Projection du contrat telle qu'exposée par le microservice Contract.
 * {@code nanti} remplace le couple (defntsm != null && ntsmt) de l'ancien modèle :
 * la logique de nantissement est calculée côté service Contract, ce microservice
 * ne fait que consommer un booléen explicite.
 */
public record ContractDTO(
        String cin,
        Integer numCat,
        String police,
        String libNumCat,
        boolean nanti,
        Integer nombreRachatsPartiels,
        LocalDate dateSouscription,
        float montantEnCours,
        float montantAvanceEnCours
) {
}
