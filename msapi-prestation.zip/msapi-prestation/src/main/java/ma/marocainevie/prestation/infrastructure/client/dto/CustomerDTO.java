package ma.marocainevie.prestation.infrastructure.client.dto;

import java.time.LocalDate;

/**
 * Projection du client telle qu'exposée par le microservice Customer.
 * Ne porte que les champs nécessaires au domaine Prestation.
 */
public record CustomerDTO(
        String cin,
        String login,
        String nom,
        String prenom,
        String email,
        LocalDate dateNaissance
) {
}
