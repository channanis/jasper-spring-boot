package ma.marocainevie.prestation.infrastructure.repository;

import ma.marocainevie.prestation.domain.model.HistoryPrestation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HistoryPrestationRepository extends JpaRepository<HistoryPrestation, Long> {
}
