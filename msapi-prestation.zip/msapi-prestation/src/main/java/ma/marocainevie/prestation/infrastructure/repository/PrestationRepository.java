package ma.marocainevie.prestation.infrastructure.repository;

import ma.marocainevie.prestation.domain.model.Prestation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PrestationRepository extends JpaRepository<Prestation, Long> {

    Optional<Prestation> findByPrestationUid(String prestationUid);
}
