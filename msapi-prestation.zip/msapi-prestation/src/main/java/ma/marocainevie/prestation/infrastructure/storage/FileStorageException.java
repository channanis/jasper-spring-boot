package ma.marocainevie.prestation.infrastructure.storage;

/** Levée quand le dépôt d'un fichier échoue côté infrastructure (FTP, réseau...). */
public class FileStorageException extends RuntimeException {

    public FileStorageException(String message) {
        super(message);
    }

    public FileStorageException(String message, Throwable cause) {
        super(message, cause);
    }
}
