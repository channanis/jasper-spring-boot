package ma.marocainevie.prestation.infrastructure.storage;

import lombok.RequiredArgsConstructor;
import ma.marocainevie.prestation.domain.service.FileStorageService;
import org.apache.commons.net.ftp.FTPClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;

@Service
@RequiredArgsConstructor
public class FtpFileStorageService implements FileStorageService {

    private static final Logger log = LoggerFactory.getLogger(FtpFileStorageService.class);

    private final FtpProperties ftpProperties;

    @Override
    public String store(byte[] content, String fileName, String folder) {
        String targetDirectory = ftpProperties.directoryBase() + folder;
        log.info("Upload FTP démarré : fileName={}, targetDirectory={}", fileName, targetDirectory);

        FTPClient ftpClient = new FTPClient();
        try {
            connect(ftpClient);
            login(ftpClient);
            ftpClient.changeWorkingDirectory(targetDirectory);

            try (ByteArrayInputStream inputStream = new ByteArrayInputStream(content)) {
                boolean stored = ftpClient.storeFile(fileName, inputStream);
                if (!stored) {
                    throw new FileStorageException("Échec du dépôt FTP pour le fichier " + fileName);
                }
            }
            log.info("Upload FTP terminé avec succès : fileName={}", fileName);
            return folder + "/" + fileName;

        } catch (IOException e) {
            throw new FileStorageException("Erreur de communication FTP lors de l'upload de " + fileName, e);
        } finally {
            disconnectQuietly(ftpClient);
        }
    }

    private void connect(FTPClient ftpClient) throws IOException {
        int port = Integer.parseInt(ftpProperties.port());
        ftpClient.setConnectTimeout(ftpProperties.timeoutMs());
        ftpClient.connect(ftpProperties.server(), port);
        int reply = ftpClient.getReplyCode();
        if (!org.apache.commons.net.ftp.FTPReply.isPositiveCompletion(reply)) {
            throw new FileStorageException("Connexion FTP refusée par le serveur, code=" + reply);
        }
    }

    private void login(FTPClient ftpClient) throws IOException {
        boolean loggedIn = ftpClient.login(ftpProperties.login(), ftpProperties.password());
        if (!loggedIn) {
            throw new FileStorageException("Authentification FTP échouée pour l'utilisateur configuré");
        }
    }

    private void disconnectQuietly(FTPClient ftpClient) {
        try {
            if (ftpClient.isConnected()) {
                ftpClient.logout();
                ftpClient.disconnect();
            }
        } catch (IOException e) {
            log.warn("Erreur non bloquante lors de la fermeture de la connexion FTP", e);
        }
    }
}
