package ma.marocainevie.prestation.infrastructure.storage;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Regroupe la configuration FTP jusqu'ici éclatée en une dizaine de champs {@code @Value}
 * distincts. Bindée depuis le préfixe {@code selfcare.mobile.ftp} d'application.yml.
 */
@ConfigurationProperties(prefix = "selfcare.mobile.ftp")
public record FtpProperties(
        String directoryBase,
        String login,
        String password,
        String cert,
        String server,
        String port,
        int timeoutMs,
        int maxFileSizeMb
) {
    public FtpProperties {
        if (port == null || port.isBlank()) {
            port = "21";
        }
    }
}
