package ma.marocainevie.prestation.domain.service;

import ma.marocainevie.prestation.api.dto.request.PrestationCreateRequest;
import ma.marocainevie.prestation.domain.exception.PrestationBusinessException;
import ma.marocainevie.prestation.domain.exception.PrestationErrorCode;
import ma.marocainevie.prestation.domain.model.enums.ModeReglement;
import ma.marocainevie.prestation.domain.model.enums.TypeProcedure;
import ma.marocainevie.prestation.infrastructure.client.dto.ContractDTO;
import ma.marocainevie.prestation.infrastructure.client.dto.CustomerDTO;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class PrestationBusinessRulesTest {

    private final PrestationBusinessRules rules = new PrestationBusinessRules();

    @Test
    void applyRGAvance_rejects_customer_under_50() {
        PrestationCreateRequest request = avanceRequest(1000f, false);
        CustomerDTO customer = customerAged(40);
        ContractDTO contract = contractSouscritIlYA(10, 10_000f, 0f, 0);

        assertThatThrownBy(() -> rules.applyRGAvance(request, customer, contract))
                .isInstanceOf(PrestationBusinessException.class)
                .extracting(e -> ((PrestationBusinessException) e).errorCode())
                .isEqualTo(PrestationErrorCode.AGE_CRITERIA);
    }

    @Test
    void applyRGAvance_rejects_contract_younger_than_8_years() {
        PrestationCreateRequest request = avanceRequest(1000f, false);
        CustomerDTO customer = customerAged(60);
        ContractDTO contract = contractSouscritIlYA(5, 10_000f, 0f, 0);

        assertThatThrownBy(() -> rules.applyRGAvance(request, customer, contract))
                .isInstanceOf(PrestationBusinessException.class)
                .extracting(e -> ((PrestationBusinessException) e).errorCode())
                .isEqualTo(PrestationErrorCode.DURE_CONTRAT_CRITERIA);
    }

    @Test
    void applyRGAvance_rejects_amount_above_80_percent_of_encours() {
        PrestationCreateRequest request = avanceRequest(9000f, false);
        CustomerDTO customer = customerAged(60);
        ContractDTO contract = contractSouscritIlYA(10, 10_000f, 0f, 0);

        assertThatThrownBy(() -> rules.applyRGAvance(request, customer, contract))
                .isInstanceOf(PrestationBusinessException.class)
                .extracting(e -> ((PrestationBusinessException) e).errorCode())
                .isEqualTo(PrestationErrorCode.MONTANT_SUPERIEUR_80_ERROR);
    }

    @Test
    void applyRGAvance_caps_amount_at_80_percent_when_valeurMaximale_requested() {
        PrestationCreateRequest request = avanceRequest(0f, true);
        CustomerDTO customer = customerAged(60);
        ContractDTO contract = contractSouscritIlYA(10, 10_000f, 0f, 0);

        float montant = rules.applyRGAvance(request, customer, contract);

        assertThat(montant).isEqualTo(8000f);
    }

    @Test
    void applyRGAvance_rejects_when_unpaid_advance_exists() {
        PrestationCreateRequest request = avanceRequest(1000f, false);
        CustomerDTO customer = customerAged(60);
        ContractDTO contract = contractSouscritIlYA(10, 10_000f, 500f, 0);

        assertThatThrownBy(() -> rules.applyRGAvance(request, customer, contract))
                .isInstanceOf(PrestationBusinessException.class)
                .extracting(e -> ((PrestationBusinessException) e).errorCode())
                .isEqualTo(PrestationErrorCode.AVANCE_NON_REMBOURSE_ERROR);
    }

    @Test
    void applyRGRachatPartiel_rejects_when_more_than_3_previous_partial_buybacks() {
        PrestationCreateRequest request = rachatPartielRequest(1000f, false);
        ContractDTO contract = contractSouscritIlYA(10, 10_000f, 0f, 4);

        assertThatThrownBy(() -> rules.applyRGRachatPartiel(request, contract))
                .isInstanceOf(PrestationBusinessException.class)
                .extracting(e -> ((PrestationBusinessException) e).errorCode())
                .isEqualTo(PrestationErrorCode.NOMBRE_RACHAT_ERROR);
    }

    @Test
    void checkVirement_requires_24_digit_rib_and_attachment() {
        PrestationCreateRequest request = new PrestationCreateRequest(
                1, "POL1", TypeProcedure.RACHAT_TOTAL, false, null, false, 100f,
                ModeReglement.VIREMENT, "12345", "Nom Prenom", null);

        assertThatThrownBy(() -> rules.checkVirement(request, true))
                .isInstanceOf(PrestationBusinessException.class)
                .extracting(e -> ((PrestationBusinessException) e).errorCode())
                .isEqualTo(PrestationErrorCode.FIELD_N_COMPTE_EXACT_24);
    }

    private PrestationCreateRequest avanceRequest(float montant, boolean valeurMaximale) {
        return new PrestationCreateRequest(1, "POL1", TypeProcedure.AVANCE, false, null,
                valeurMaximale, montant, ModeReglement.CHEQUE, null, "Nom Prenom", null);
    }

    private PrestationCreateRequest rachatPartielRequest(float montant, boolean valeurMaximale) {
        return new PrestationCreateRequest(1, "POL1", TypeProcedure.RACHAT_PARTIEL, false, null,
                valeurMaximale, montant, ModeReglement.CHEQUE, null, "Nom Prenom", null);
    }

    private CustomerDTO customerAged(int age) {
        return new CustomerDTO("CIN1", "login1", "Nom", "Prenom", "a@b.com", LocalDate.now().minusYears(age));
    }

    private ContractDTO contractSouscritIlYA(int annees, float montantEnCours, float montantAvanceEnCours, int nbRachats) {
        return new ContractDTO("CIN1", 1, "POL1", "LIB", false, nbRachats,
                LocalDate.now().minusYears(annees), montantEnCours, montantAvanceEnCours);
    }
}
